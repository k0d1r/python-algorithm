"""
doğum tarihi girilen kişinin yaşını bulan program

"""

dogumTarihi = int(input("Doğum tarihinizi giriniz: "))

yas = 2019 - dogumTarihi

print("Yasiniz: ", yas)