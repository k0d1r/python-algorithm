"""
girilen sayinin tek mi çift mi olduğunu bulan program

"""

girilenSayi = int(input("Bir sayi giriniz: "))

if girilenSayi %2 == 0:
    print("Girdiğiniz sayi çift bir sayi.")
else:
    print("Girdiğiniz sayi tek bir sayi.")
