"""
0 ile 100 arasındaki sayilarda 7 ye bölümünden 3 kalanını veren
sayilari ekrana yazdıran program

"""

for i in range(1,100):
    if (i % 7 == 3):
        print(i)