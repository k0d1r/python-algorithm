"""
1'den başlayıp kullanıcın girdiği sayiya kadarki sayilari ekrana yazdıran program

"""

girilenSayi = int(input("Sayi = "))

for i in range(1, girilenSayi):
    print(i)