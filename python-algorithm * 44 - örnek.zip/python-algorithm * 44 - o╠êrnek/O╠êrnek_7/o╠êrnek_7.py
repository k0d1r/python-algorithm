"""
iki sayinin ortalamasini bulan program

"""

birinciSayi = int(input("Birinci sayiyi giriniz: "))
ikinciSayi = int(input("İkinci sayiyi giriniz: "))

ort = (birinciSayi + ikinciSayi)/2;

print("İki sayinin ortalamasi: ", ort)