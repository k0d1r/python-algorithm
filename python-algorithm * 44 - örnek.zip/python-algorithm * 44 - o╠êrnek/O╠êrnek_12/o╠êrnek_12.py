"""
10 ile 1000 arasındaki tam kare sayilari ekrana yazdıran program

"""

for i in range (4, 40):
    if (i*i <1000):
        print("{} bir tamkare sayidir. ".format(i*i))
