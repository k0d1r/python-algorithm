"""
Girilen sayinin karekökünü bulan program

"""
import math

girilenSayi = int(input("sayi : "))

girilenSayi = math.sqrt(girilenSayi)

print("Girdiğiniz sayinin karekökü = ", girilenSayi)