"""
Girilen kelimeyi harflerine ayiran program

"""

kelime = input("Bir kelime giriniz: ")

for i in kelime:
    print(i)