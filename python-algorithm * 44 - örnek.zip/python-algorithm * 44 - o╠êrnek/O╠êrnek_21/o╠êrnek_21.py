"""
1'den 500'e kadar olan sayilarin toplamını veren program

"""
toplam = 0

for i in range(1, 501):
    toplam += i

print(toplam)