""""
Kullanıcı tarafından girilen iki sayının toplamını veren program

"""


birinciSayi = input("birinci sayiyi giriniz: ")
ikinciSayi = input("ikinci sayiyi giriniz: ")

print("iki sayinin toplami = ", int(birinciSayi) + int(ikinciSayi))