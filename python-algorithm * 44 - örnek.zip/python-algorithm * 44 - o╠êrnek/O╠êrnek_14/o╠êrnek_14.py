"""
Girilen sayinin 4 ün katı olup olmadığını söyleyen program

"""

girilenSayi = int(input("Bir sayi giriniz: "))

if girilenSayi % 4 == 0:
    print("Girdiğiniz sayi dördün katıdır.")

else:
    print("Girdiğiniz sayi dördün katı değil.")
