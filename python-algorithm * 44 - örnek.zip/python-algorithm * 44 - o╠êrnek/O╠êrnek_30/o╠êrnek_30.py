"""
İki açısı girilen üçgenin üçüncü açısını bulan program

"""

aci1 = int(input("Birinci Aci : "))
aci2 = int(input("İkinci Aci : "))

print("Ücüncü aci = ", 180 - (aci1 + aci2))