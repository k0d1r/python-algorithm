"""
nota göre sınıf geçme durumunu söyleyen program

"""

dersNotu = int((input("Ders notunuzu giriniz: ")))

if dersNotu >= 50:
    input("Sınıfı geçtiniz")

else:
    print("Sınıfta Kaldınız. Hayırlısı Olsun! ")